module example.test/fixture

go 1.22
require example.test/dependency v1.0.0
replace example.test/dependency => ../dependency
