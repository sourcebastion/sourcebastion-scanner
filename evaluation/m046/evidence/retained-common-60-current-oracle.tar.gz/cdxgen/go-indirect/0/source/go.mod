module example.test/fixture

go 1.22

require golang.org/x/text v0.18.0 // indirect
