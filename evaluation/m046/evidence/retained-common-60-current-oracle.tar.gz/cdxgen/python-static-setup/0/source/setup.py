from setuptools import setup
setup(name="fixture", install_requires=["requests==2.32.3"])
