from pathlib import Path
Path("EXECUTED").write_text("unsafe")
from setuptools import setup
setup(name="fixture", install_requires=compute_dependencies())
