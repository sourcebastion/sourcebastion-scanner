# Current 64-case comparison of retained candidate output

Generated from digest-checked historical AMD64 raw output, re-compared to the current independent oracle. Extraction was not rerun. Exact source trees, projection transformation maps, imported comparison code and retained trace/raw digests are checked before/after. Projection inputs include explicitly labelled synthetic copies. Four later cases remain not evaluated for these stock profiles. Counts include empty negative agreements and are not accuracy percentages. No trace admission is upgraded. The corrected Poetry fragment oracle refuses missing metadata instead of selecting its version, changing all four historical basic totals by one.

| Profile | Retained cases | Not evaluated | Exact packages/edges | Also exact applications | Rich full contract |
| --- | ---: | ---: | ---: | ---: | ---: |
| syft | 60 | 4 | 38 | 37 | 0 |
| cdxgen | 60 | 4 | 32 | 9 | 0 |
| scalibr | 60 | 4 | 38 | 38 | 0 |
| syft-projection | 60 | 4 | 43 | 42 | 0 |

Stock profiles leave rich dimensions unreported. The projection is an exact-pin diagnostic, not the substantive extension. Current direct-Python and restricted-provider evidence is separate; no mixed-profile result is reported as one measured hybrid route.

All historical process/network/write evidence retains its original limitations. The independent current restricted-provider review establishes separate native observations, not retroactive success for these stock tools.
