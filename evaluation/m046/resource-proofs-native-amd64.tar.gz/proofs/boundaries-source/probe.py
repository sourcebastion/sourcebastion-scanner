
import json, os, socket, subprocess, sys, time
from pathlib import Path
import platform
mode = Path('/source/mode').read_text().strip()
result = {'uid':os.geteuid(), 'status':Path('/proc/self/status').read_text()}
if mode == 'boundaries':
    attempts={}
    for name in ('/source/mutation', '/output/measurement.json', '/output/go', '/output/ack', '/output/heartbeat', '/output/result.json'):
        try:
            Path(name).write_text('forged')
            attempts[name]='accepted'
        except OSError as error:
            attempts[name]=error.errno
    sock=socket.socket()
    sock.settimeout(.5)
    try:
        sock.connect(('192.0.2.1',443))
        attempts['network']='accepted'
    except OSError as error:
        attempts['network']=error.errno
    finally:
        sock.close()
    result['attempts']=attempts
if mode in ('escape', 'watchdog', 'driver-death'):
    child=subprocess.Popen([sys.executable,'-c',"import os,time; from pathlib import Path; Path('/work/child-ready').write_text(str(os.getpid())); time.sleep(300)"],start_new_session=True)
    until=time.monotonic()+5
    while not Path('/work/child-ready').exists():
        assert time.monotonic()<until
        time.sleep(.01)
    result['escaped_child_pid']=child.pid
if mode == 'symlink':
    os.symlink('/source/private-sentinel','/work/raw.json')
else:
    Path('/work/raw.json').write_text(json.dumps(result))
if mode in ('watchdog','driver-death'):
    time.sleep(300)
if mode == 'cpu':
    while True:
        sum(range(100000))
if mode == 'memory':
    blocks=[]
    while True:
        blocks.append(bytearray(16*1024*1024))
if mode == 'tmpfs':
    total=0
    filesystem=os.statvfs('/work')
    capacity=filesystem.f_frsize*filesystem.f_blocks
    try:
        for number in range(6):
            with open('/work/blob'+str(number),'wb') as stream:
                for _ in range(60):
                    total+=stream.write(b'x'*1024*1024)
    except OSError as error:
        Path('/work/raw.json').write_text(json.dumps({'errno':error.errno,'bytes_written':total,'capacity_bytes':capacity}))
