"""Recompare retained synthetic raw outputs, without rerunning old candidates.

Current expectations never change extraction. Historical trace/profile evidence
keeps its original admission status. Missing new cases stay not-evaluated.
"""

import argparse
import hashlib
import json
from pathlib import Path
import resource
import re
import signal
import subprocess
import sys

resource.setrlimit(resource.RLIMIT_AS, (1024**3,) * 2)
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2,) * 2)
signal.alarm(150)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source", type=Path, required=True, help="trusted checkout containing the pinned comparator")
parser.add_argument("--retained", type=Path, required=True, help="verified synthetic retained tree")
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
SOURCE = args.source.resolve(strict=True)
OUT = args.output.resolve()
OUT.mkdir(parents=True, exist_ok=True)
BASE = args.retained.resolve(strict=True)
sys.path.insert(0, str(SOURCE))
from evaluation.m046.corpus import CORPUS
from evaluation.m046.run import PIN, compare, normalize


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def read(path):
    if path.stat().st_size > 64 * 1024**2:
        raise ValueError("retained-file-budget-exceeded")
    with path.open("rb") as stream:
        data = stream.read(64 * 1024**2 + 1)
    if len(data) > 64 * 1024**2:
        raise ValueError("retained-file-budget-exceeded")
    return data


def source_bindings():
    result = {}
    for module in list(sys.modules.values()):
        filename = getattr(module, "__file__", None)
        if filename is None or not Path(filename).is_relative_to(SOURCE / "evaluation/m046"):
            continue
        path = Path(filename)
        relative = str(path.relative_to(SOURCE))
        committed = subprocess.check_output(["rtk", "proxy", "git", "show", "4774e199279d9267fb9f7cc59f3834289bf9c4b1:" + relative], cwd=SOURCE)
        if read(path) != committed:
            raise ValueError("imported-source-differs-from-claimed-head")
        result[relative] = sha(path)
    return result


def verify_tree(source, fixture, projection):
    expected = dict(fixture["files"])
    for row in projection:
        original, projected = row["original"], row["projected"]
        directory = hashlib.sha256(original.encode()).hexdigest()
        if projected != f".m046-projection/{directory}/requirements.txt" or row["sha256"] != hashlib.sha256(expected[original].encode()).hexdigest():
            raise ValueError("invalid-projection-origin-map")
        pins = []
        for line in expected[original].replace("\\\n", " ").splitlines():
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            line = re.sub(r"\s+--hash=sha256:[a-fA-F0-9]{64}(?=\s|$)", "", line).strip()
            if not PIN.fullmatch(line):
                raise ValueError("unadmitted-projected-pin")
            pins.append(line)
        if not pins:
            raise ValueError("empty-projected-pins")
        expected[projected] = "\n".join(pins) + "\n"
    expected_paths = set(expected) | set(fixture["symlinks"])
    for name in list(expected_paths):
        expected_paths.update(str(p) for p in Path(name).parents if str(p) != ".")
    actual_paths = {str(p.relative_to(source)) for p in source.rglob("*")}
    if len(actual_paths) > 100000 or actual_paths != expected_paths or source.is_symlink():
        raise ValueError("unexpected-retained-input-tree")
    for path, content in expected.items():
        actual = source / path
        if actual.is_symlink() or not actual.is_file() or read(actual) != content.encode():
            raise ValueError("changed-fixture-input")
        if any(parent.is_symlink() for parent in actual.parents if parent != source.parent):
            raise ValueError("symlink-input-ancestor")
    for path, target in fixture["symlinks"].items():
        if not (source / path).is_symlink() or str((source / path).readlink()) != target:
            raise ValueError("changed-fixture-symlink")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def main():
    bindings = source_bindings()
    fixtures = {row["id"]: row for row in CORPUS}
    result = {
        "schema": "m046-current-oracle-retained-candidate-comparison-v1",
        "status": "diagnostic-not-engine-selection",
        "source_head": "4774e199279d9267fb9f7cc59f3834289bf9c4b1",
        "corpus_count": len(CORPUS),
        "current_corpus_sha256": hashlib.sha256(canonical(CORPUS)).hexdigest(),
        "source_sha256": bindings,
        "scope": "Old AMD64 raw extraction, current oracle comparison only; not new execution, current-head native CI, strict trace acceptance, or vulnerability accuracy",
        "candidates": {},
    }
    markdown = [
        "# Current 64-case comparison of retained candidate output",
        "",
        "Generated from digest-checked historical AMD64 raw output, re-compared to the current independent oracle. Extraction was not rerun. Exact source trees, projection transformation maps, imported comparison code and retained trace/raw digests are checked before/after. Projection inputs include explicitly labelled synthetic copies. Four later cases remain not evaluated for these stock profiles. Counts include empty negative agreements and are not accuracy percentages. No trace admission is upgraded. The corrected Poetry fragment oracle refuses missing metadata instead of selecting its version, changing all four historical basic totals by one.",
        "",
        "| Profile | Retained cases | Not evaluated | Exact packages/edges | Also exact applications | Rich full contract |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for name in ("syft", "cdxgen", "scalibr", "syft-projection"):
        report_path = BASE / name / "report.json"
        old = json.loads(read(report_path))
        keys = [(row["fixture"], row["repetition"]) for row in old["records"]]
        ids = {name for name, _ in keys}
        if len(keys) != 120 or len(ids) != 60 or set(keys) != {(name, rep) for name in ids for rep in (0, 1)}:
            raise ValueError("invalid-historical-repeat-denominator")
        attempts, pairs = [], {}
        for record in old["records"]:
            fixture = fixtures[record["fixture"]]
            root = BASE / name / record["fixture"] / str(record["repetition"])
            source = root / "source"
            projection = record["projection"]
            if projection and name != "syft-projection":
                raise ValueError("unexpected-profile-transformation")
            verify_tree(source, fixture, projection)
            if record["source_unchanged"] is not True:
                raise ValueError("historical source uncertainty")
            raw, trace = root / "run/raw.json", root / "run/trace.log"
            if not trace.is_file() or sha(trace) != record["trace_sha256"]:
                raise ValueError("trace digest mismatch")
            usable = record["metrics"]["exit_code"] == 0 and not record["metrics"]["timed_out"] and record.get("raw_sha256") is not None
            observed = None
            if record.get("raw_sha256") is not None:
                if not raw.is_file() or sha(raw) != record["raw_sha256"]:
                    raise ValueError("raw digest mismatch")
                observed = normalize(json.loads(read(raw)), name)
            elif raw.exists():
                raise ValueError("unbound-unexpected-raw-output")
            current = compare(fixture["expected"], observed) if usable and observed is not None else None
            row = {
                "fixture": fixture["id"], "repetition": record["repetition"],
                "raw_sha256": record.get("raw_sha256"), "trace_sha256": record["trace_sha256"],
                "historical_output_error": record.get("output_error"),
                "original_metrics": record["metrics"], "original_trace_admission": record["audit_status"],
                "fixture_inputs_equal_current": True, "current_comparison": current,
                "input_profile": "transformed-exact-pin-projection" if projection else "original-fixture",
                "projection": projection,
                "observed": observed, "execution_usable": usable,
            }
            attempts.append(row)
            pairs.setdefault(fixture["id"], []).append(row)
            verify_tree(source, fixture, projection)
            if sha(trace) != record["trace_sha256"] or (record.get("raw_sha256") is not None and sha(raw) != record["raw_sha256"]):
                raise ValueError("retained-evidence-changed-during-comparison")
        rows = []
        for fixture in CORPUS:
            retained = pairs.get(fixture["id"], [])
            comparisons = [row["current_comparison"] for row in retained]
            basic = bool(retained) and all(
                current is not None and not any(current[key] for key in ("missing_packages", "extra_packages", "missing_edges", "extra_edges"))
                for current in comparisons
            )
            applications = basic and all(not current["missing_applications"] and not current["extra_applications"] for current in comparisons)
            rows.append({
                "fixture": fixture["id"], "ecosystem": fixture["ecosystem"],
                "status": "retained-raw-recomparison" if retained else "not-evaluated",
                "retained_attempts": len(retained), "basic_package_edge_agreement": basic,
                "also_application_agreement": applications,
                "full_contract_agreement": bool(retained) and all(current is not None and current["full_contract_agreement"] for current in comparisons),
                "repeat_observed_equal": len(retained) == 2 and all(row["execution_usable"] for row in retained) and canonical(retained[0]["observed"]) == canonical(retained[1]["observed"]),
            })
        counts = {
            "retained_cases": len(pairs), "not_evaluated": len(CORPUS) - len(pairs),
            "basic_agreements": sum(row["basic_package_edge_agreement"] for row in rows),
            "also_application_agreements": sum(row["also_application_agreement"] for row in rows),
            "full_contract_agreements": sum(row["full_contract_agreement"] for row in rows),
        }
        result["candidates"][name] = {"historical_report_sha256": sha(report_path), "binary_sha256": old["binary_sha256"], "historical_oracle_sha256": old["oracle_sha256"], "counts": counts, "cases": rows, "attempts": attempts}
        markdown.append(f"| {name} | {counts['retained_cases']} | {counts['not_evaluated']} | {counts['basic_agreements']} | {counts['also_application_agreements']} | {counts['full_contract_agreements']} |")
    if source_bindings() != bindings:
        raise ValueError("changed-imported-source")
    result["builder_sha256"] = sha(Path(__file__))
    destination = OUT / "current-comparison"
    destination.mkdir(exist_ok=True)
    (destination / "retained-current-oracle.json").write_bytes(json.dumps(result, indent=2, sort_keys=True).encode() + b"\n")
    markdown.extend(["", "Stock profiles leave rich dimensions unreported. The projection is an exact-pin diagnostic, not the substantive extension. Current direct-Python and restricted-provider evidence is separate; no mixed-profile result is reported as one measured hybrid route.", "", "All historical process/network/write evidence retains its original limitations. The independent current restricted-provider review establishes separate native observations, not retroactive success for these stock tools."])
    (destination / "retained-current-oracle.md").write_text("\n".join(markdown) + "\n")
    print(json.dumps({"report_sha256": sha(destination / "retained-current-oracle.json"), "counts": {name: record["counts"] for name, record in result["candidates"].items()}}))


if __name__ == "__main__":
    main()
